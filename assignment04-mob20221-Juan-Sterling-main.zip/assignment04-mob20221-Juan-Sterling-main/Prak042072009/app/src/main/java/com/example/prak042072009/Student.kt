package com.example.prak042072009

import android.os.Parcelable
//
//class Student (
//    val namadepan: String,
//    val namabelakang: String,
//    val alamat: String
//):Parcelable


