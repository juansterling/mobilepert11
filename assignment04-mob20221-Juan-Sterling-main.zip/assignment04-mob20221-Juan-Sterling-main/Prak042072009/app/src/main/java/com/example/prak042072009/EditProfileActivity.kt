package com.example.prak042072009

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.prak042072009.databinding.ActivityEditProfileBinding
import com.example.prak042072009.databinding.ActivityProfileBinding

class EditProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityEditProfileBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnedit.setOnClickListener {
            val nrp = binding.editnrp.text.toString()
            val namadepan = binding.editnamadepan.text.toString()
            val namabelakang = binding.editnamabelakang.text.toString()
            val alamat = binding.editalamat.text.toString()
            val email = binding.editemail.text.toString()
            val intentback = Intent(this@EditProfileActivity,ProfileActivity::class.java)
            intentback.putExtra("nrp",nrp)
            intentback.putExtra("namadepan",namadepan)
            intentback.putExtra("namabelakang",namabelakang)
            intentback.putExtra("alamat",alamat)
            intentback.putExtra("email",email)

            startActivity(intentback)
            finishAffinity()
//            val bundle = Bundle()
//            bundle.putString("abc", nrp)
//            intentedit.putExtras(bundle)
//            intent.putExtra(Intent.EXTRA_TEXT,nrp)
//            intent.putExtra(Intent.EXTRA_TEXT,namadepan)
//            intent.putExtra(Intent.EXTRA_TEXT,namabelakang)
//            intent.putExtra(Intent.EXTRA_TEXT,alamat)
//            intent.putExtra(Intent.EXTRA_TEXT,email)
        }
    }

    override fun onStart() {
        super.onStart()
        val nrp = intent.getStringExtra("nrp")
        val namadepan = intent.getStringExtra("namadepan")
        val namabelakang = intent.getStringExtra("namabelakang")
        val alamat = intent.getStringExtra("alamat")
        val email = intent.getStringExtra("email")

       binding.editnrp.setText(nrp)

        binding.editnamadepan.setText(namadepan)

        binding.editnamabelakang.setText(namabelakang)

        binding.editalamat.setText(alamat)

        binding.editemail.setText(email)

    }
}