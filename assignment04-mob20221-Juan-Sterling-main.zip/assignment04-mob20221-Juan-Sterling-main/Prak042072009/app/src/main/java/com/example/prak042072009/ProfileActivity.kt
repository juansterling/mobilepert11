package com.example.prak042072009

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.prak042072009.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var firebaseAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        firebaseAuth = Firebase.auth
        binding.btnedit.setOnClickListener {
            Firebase.auth.signOut()
            val intent = Intent(this@ProfileActivity,LoginActivity::class.java)
            startActivity(intent)
            this.finish()

//            val bundle = Bundle()
//            bundle.putString("abc", nrp)
//            intentedit.putExtras(bundle)

        }
    }

    override fun onStart() {
        super.onStart()
        val currentuser = firebaseAuth.currentUser
        binding.hasilnrp.text = currentuser?.email



    }


}